gcc pcmtool.c -o pcmtool

